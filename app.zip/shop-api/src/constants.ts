export const jwtSecret = 'lkj20JLKFDJ023@#$#@)(*!)(*$';
export const saltRounds = 10;
export const salt = '342890rY&*($@#EDHSAlkfjgh420984SADF32';
