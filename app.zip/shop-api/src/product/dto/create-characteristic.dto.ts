export class CreateCharacteristicDTO {
  id?: number;
  name: string;
  value: string;
}
