
export class CreateCharacteristicDescriptorDTO {
  name: string;
  description?: string;
}
