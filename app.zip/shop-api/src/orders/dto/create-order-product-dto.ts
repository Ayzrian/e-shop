export class CreateOrderProductDTO {
  productId: number;
  amount: number;
  priceAtTheMomentOfOrder?: number;
}
