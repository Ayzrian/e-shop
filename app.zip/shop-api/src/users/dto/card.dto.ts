
export class CardDTO {
  cardNumber: string;
  expirationDate: string;
  cvv: string;
}
