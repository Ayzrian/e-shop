
export class AddressDTO {
  country: string;
  city: string;
  street: string;
  building: string;
  flat?: string;
}
