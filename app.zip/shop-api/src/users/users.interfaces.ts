export enum EUserRole {
  ADMIN = 'ADMIN',
  USER = 'USER',
}
