#! /bin/bash

cd /src

npm install

npm run start
