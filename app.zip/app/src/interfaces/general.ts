
export interface INavLink {
  route: string;
  text: string;
  icon?: string;
}
